const title = document.querySelector('title');
const fileName = document.querySelector('#fileName');
const file = document.querySelector('#file');
const body = document.querySelector('body');
const view = document.querySelector('#view');
const clearbtn = document.querySelector('#clearbtn');
const uploadbtn = document.querySelector('#uploadbtn');
const firebaseConfig = {
    apiKey: "AIzaSyBaPvnzqor_4HfPZg6ayk30Tb1RpcMBWfo",
    authDomain: "test-66b58.firebaseapp.com",
    projectId: "test-66b58",
    storageBucket: "test-66b58.appspot.com",
    messagingSenderId: "39985206495",
    appId: "1:39985206495:web:c4200c42a6e7bad4da456a",
    measurementId: "G-G1RBDR6H1S"
};
const box = document.createElement('textarea');

file.value="";
fileName.value="";
var realFileName;
firebase.initializeApp(firebaseConfig);
const storage = firebase.storage();
var Files;
var currentSelectedFile;
file.addEventListener('change', e => {
	Files = e.target.files;
	reader = new FileReader
	box.setAttribute('class','textArea');
	
	reader.onload = () => {
		box.textContent=reader.result;
	}
	
	reader.readAsDataURL(Files[0]);
	
	console.log(Files)
	
	view.appendChild(box);
	fileName.value=e.srcElement.value;
	currentSelectedFile=e.srcElement.value;
	
	title.textContent=file.files[0].name;
	realFileName=file.files[0].name;
});

document.querySelector('#btn').onclick = () => {
	file.click();
};

clearbtn.onclick= () => {
	view.removeChild(view.firstElementChild);
}
uploadbtn.onclick= () => {
	if(file.value){
		upload(realFileName);
	}else{
		alert('Select a file to upload');
	}
}

function upload(name) {
	var Name = name.replace(/\.[^/.]+$/, "")
	alert(Name);
	if (file.value){
		var uploadTask = storage.ref('Main/UploadedFiles/'+name).put(Files[0]);
		uploadTask.on('state_changed', function(snapshot){
			console.log('uploading...');
		},
		function(error){
			alert('Error in uploading file');
		},
		function(){
			uploadTask.snapshot.ref.getDownloadURL().then(function(url){
				FileUrl = url;
				
				firebase.database().ref('Main/UploadedFiles/'+Name).set({
					name:Name,
					link:FileUrl
				});
				alert('File Uploaded successfully');
				}
			);
		});
	}else{
		alert('You need to select a file to upload.');
	}
}

